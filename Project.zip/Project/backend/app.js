
// include expressjs
const express = require("express");
// created a expressjs app
const app = express();
const bodyParser = require('body-parser')
const morgan = require('morgan')
const helmet = require('helmet')
const cookieParser = require('cookie-parser')

require('./db')
const authRouter = require('./Routes/auth')
const userRouter = require('./Routes/user')

require('dotenv').config();

app.use(helmet())
app.use(morgan('dev'))
app.use(express.static('public'))
app.use(cookieParser())
app.use(bodyParser.urlencoded({extended:true}))
app.use(bodyParser.json())

app.use('/auth', authRouter)
app.use('/user', userRouter)

//function to listen to port                                                                                                                                                
app.listen(5000,() => {console.log("server is running on port 5000")})