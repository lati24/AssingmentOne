const User = require('../models/User');

exports.updateUser = (req, res, next) => {
    User.findOneAndUpdate(
        {email: req.user.email},
        {
            $set: {
                email: req.body.employeeEmail,
                address: req.body.employeeAddress,
            },
        },
        {new : true}
    )
        .then((data) => {
            res.send({type:'sucess', msg:'Sucessfully updated profile'});
        })
        .catch((err) => {
            console.log(err)
            res.send({type:'error', msg:'Failed to update user'});
        });
};